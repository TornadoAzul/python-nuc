# Emmanuel Alicea Rodríguez.
# Número de estudiante: 2102785633.
# Sábado, 2 de septiembre de 2023.
# Tarea 1.1.

# Explicación:
# Este programa Python le pide al usuario ingresar el código del curso que está cursando.
# Con esto, convertirá sus letras de minusculas a mayúsculas junto a un saludo.

# Se le pide al usuario su código del curso:
curso_code = input("🎓 Ingresa el código del tu curso actual: ")

# Esto convertirá el código a mayúsculas:
mayusculas = curso_code.upper()

# Ahora mostrará el saludo junto al código del curso:
print("🤗 ¡Bienvenido al curso " + mayusculas + "!")
